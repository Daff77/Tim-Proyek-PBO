/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Daffa Danendra
 */
import java.time.LocalDate;

public class Stok {

    private String idStok;
    private String idMenu;
    private String kodeBatch;        // ✅ NEW - Identifikasi batch unik
    private String supplier;         // ✅ NEW  
    private double hargaBeli;        // ✅ NEW
    private int jumlah;
    private LocalDate tanggalMasuk;
    private LocalDate tanggalKadaluarsa;
    private String status;
    private String keterangan;       // ✅ NEW

    // Constructors
    public Stok() {
    }

    // Constructor untuk batch management
    public Stok(String idMenu, String kodeBatch, String supplier, double hargaBeli,
            int jumlah, LocalDate tanggalMasuk, LocalDate tanggalKadaluarsa, String keterangan) {
        this.idMenu = idMenu;
        this.kodeBatch = kodeBatch;
        this.supplier = supplier;
        this.hargaBeli = hargaBeli;
        this.jumlah = jumlah;
        this.tanggalMasuk = tanggalMasuk;
        this.tanggalKadaluarsa = tanggalKadaluarsa;
        this.status = "AKTIF";
        this.keterangan = keterangan;
    }

    // Constructor lama (untuk compatibility)
    public Stok(String idMenu, int jumlah, LocalDate tanggalMasuk) {
        this(idMenu, "BATCH-" + System.currentTimeMillis(), "Supplier Default", 0,
                jumlah, tanggalMasuk, null, null);
    }

    public Stok(String idMenu, int jumlah, LocalDate tanggalMasuk, LocalDate tanggalKadaluarsa) {
        this(idMenu, "BATCH-" + System.currentTimeMillis(), "Supplier Default", 0,
                jumlah, tanggalMasuk, tanggalKadaluarsa, null);
    }

    // Getters & Setters
    public String getIdStok() {
        return idStok;
    }

    public void setIdStok(String idStok) {
        this.idStok = idStok;
    }

    public String getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(String idMenu) {
        this.idMenu = idMenu;
    }

    public String getKodeBatch() {
        return kodeBatch;
    }

    public void setKodeBatch(String kodeBatch) {
        this.kodeBatch = kodeBatch;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public double getHargaBeli() {
        return hargaBeli;
    }

    public void setHargaBeli(double hargaBeli) {
        this.hargaBeli = hargaBeli;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public LocalDate getTanggalMasuk() {
        return tanggalMasuk;
    }

    public void setTanggalMasuk(LocalDate tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    public LocalDate getTanggalKadaluarsa() {
        return tanggalKadaluarsa;
    }

    public void setTanggalKadaluarsa(LocalDate tanggalKadaluarsa) {
        this.tanggalKadaluarsa = tanggalKadaluarsa;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    // Helper method untuk cek apakah stok expired
    public boolean isExpired() {
        if (tanggalKadaluarsa == null) {
            return false;
        }
        return LocalDate.now().isAfter(tanggalKadaluarsa);
    }

    // Helper method untuk cek stok hampir expired (7 hari lagi)
    public boolean isHampirExpired() {
        if (tanggalKadaluarsa == null) {
            return false;
        }
        LocalDate tujuhHariLagi = LocalDate.now().plusDays(7);
        return !isExpired() && (tanggalKadaluarsa.isBefore(tujuhHariLagi) || tanggalKadaluarsa.isEqual(tujuhHariLagi));
    }

    @Override
    public String toString() {
        return kodeBatch + " - Qty: " + jumlah + " - Exp: "
                + (tanggalKadaluarsa != null ? tanggalKadaluarsa : "No Expiry");
    }
}
