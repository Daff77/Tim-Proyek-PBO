/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Daffa Danendra
 */
import java.time.LocalDateTime;
import java.util.List;

public class Pesanan {

    private String idPesanan;
    private String idPengguna;
    private LocalDateTime tanggalPesanan;
    private double total;
    private String status;
    private int noMeja;
    private List<DetailPesanan> detailPesananList;

    public Pesanan() {
        this.tanggalPesanan = LocalDateTime.now(); // ✅ TANGGAL OTOMATIS
        this.status = "selesai";
        this.noMeja = 0; // Default Take Away
    }

    public Pesanan(String idPengguna, double total, int noMeja) {
        this();
        this.idPengguna = idPengguna;
        this.total = total;
        this.noMeja = noMeja;
    }

    // Getters
    public String getIdPesanan() {
        return idPesanan;
    }

    public String getIdPengguna() {
        return idPengguna;
    }

    public LocalDateTime getTanggalPesanan() {
        return tanggalPesanan;
    }

    public double getTotal() {
        return total;
    }

    // ✅ PERBAIKI: Gunakan field status yang konsisten
    public String getStatus() {
        return status;
    }

    public List<DetailPesanan> getDetailPesananList() {
        return detailPesananList;
    }

    public int getNoMeja() {
        return noMeja;
    }

    // Setters
    public void setIdPesanan(String idPesanan) {
        this.idPesanan = idPesanan;
    }

    public void setIdPengguna(String idPengguna) {
        this.idPengguna = idPengguna;
    }

    public void setTanggalPesanan(LocalDateTime tanggalPesanan) {
        this.tanggalPesanan = tanggalPesanan;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    // ✅ PERBAIKI: Gunakan field status yang konsisten
    public void setStatus(String status) {
        this.status = status;
    }

    public void setDetailPesananList(List<DetailPesanan> detailPesananList) {
        this.detailPesananList = detailPesananList;
    }

    public void setNoMeja(int noMeja) {
        this.noMeja = noMeja;
    }
}
