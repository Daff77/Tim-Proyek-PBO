/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author Daffa Danendra
 */
import service.MenuService;
import service.StokService;
import model.Menu;
import model.Stok;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

public class StokManagementForm extends JFrame {

    private MenuService menuService;
    private StokService stokService;
    private JTable tableMenu;
    private DefaultTableModel tableModel;

    public StokManagementForm(MenuService menuService) {
        this.menuService = menuService;
        this.stokService = new StokService();
        initUI();
        loadDataMenu();
    }

    private void initUI() {
        setTitle("Kelola Stok Menu - Cafe Management System");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel lblTitle = new JLabel("📦 KELOLA STOK MENU", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        // Panel tombol aksi
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton btnTambahStok = new JButton("📥 Tambah Stok Baru");
        btnTambahStok.setBackground(new Color(60, 179, 113));
        btnTambahStok.setForeground(Color.WHITE);
        btnTambahStok.setFocusPainted(false);
        btnTambahStok.addActionListener(e -> tambahStokBaru());

        JButton btnLihatDetailStok = new JButton("👀 Lihat Detail Stok");
        btnLihatDetailStok.setBackground(new Color(70, 130, 180));
        btnLihatDetailStok.setForeground(Color.WHITE);
        btnLihatDetailStok.setFocusPainted(false);
        btnLihatDetailStok.addActionListener(e -> lihatDetailStok());

        JButton btnRefresh = new JButton("🔄 Refresh");
        btnRefresh.addActionListener(e -> loadDataMenu());

        JButton btnTutup = new JButton("Tutup");
        btnTutup.addActionListener(e -> dispose());

        buttonPanel.add(btnTambahStok);
        buttonPanel.add(btnLihatDetailStok);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnTutup);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Table untuk menu dengan stok
        String[] columnNames = {"ID", "Nama Menu", "Harga", "Kategori", "Stok Tersedia", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableMenu = new JTable(tableModel);
        tableMenu.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableMenu.setRowHeight(25);
        tableMenu.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));

        // Set column widths
        tableMenu.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID
        tableMenu.getColumnModel().getColumn(1).setPreferredWidth(200); // Nama Menu
        tableMenu.getColumnModel().getColumn(2).setPreferredWidth(100); // Harga
        tableMenu.getColumnModel().getColumn(3).setPreferredWidth(150); // Kategori
        tableMenu.getColumnModel().getColumn(4).setPreferredWidth(100); // Stok Tersedia
        tableMenu.getColumnModel().getColumn(5).setPreferredWidth(100); // Status

        JScrollPane scrollPane = new JScrollPane(tableMenu);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    private void loadDataMenu() {
        tableModel.setRowCount(0);
        List<Menu> menuList = menuService.getAllMenu();

        int stokHabis = 0;
        int stokSedikit = 0;

        for (Menu menu : menuList) {
            // Hitung stok tersedia dari StokService
            int stokTersedia = stokService.getTotalStokTersedia(menu.getIdMenu());
            String status = getStatusStok(stokTersedia);
            
            if (status.equals("HABIS")) {
                stokHabis++;
            }
            if (status.equals("SEDIKIT")) {
                stokSedikit++;
            }

            Object[] rowData = {
                menu.getIdMenu(),
                menu.getNamaMenu(),
                menuService.formatHarga(menu.getHarga()),
                menu.getKategori(),
                stokTersedia,
                status
            };
            tableModel.addRow(rowData);
        }

        setTitle("Kelola Stok - " + menuList.size() + " items | Habis: " + stokHabis + " | Sedikit: " + stokSedikit);
        System.out.println("✅ Loaded " + menuList.size() + " menu items for stok management");
    }

    private String getStatusStok(int stok) {
        if (stok == 0) {
            return "HABIS";
        }
        if (stok <= 10) {
            return "SEDIKIT";
        }
        if (stok <= 20) {
            return "CUKUP";
        }
        return "BAIK";
    }

    // ✅ METHOD TAMBAH STOK BARU YANG DIPERBAIKI
    private void tambahStokBaru() {
        // Ambil menu yang dipilih
        int selectedRow = tableMenu.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Pilih menu terlebih dahulu!",
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idMenu = (String) tableModel.getValueAt(selectedRow, 0);
        String namaMenu = (String) tableModel.getValueAt(selectedRow, 1);
        int stokSekarang = (Integer) tableModel.getValueAt(selectedRow, 4);

        // Form input stok baru yang lebih lengkap
        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
        panel.setPreferredSize(new Dimension(500, 300));

        // Generate kode batch otomatis
        String kodeBatch = stokService.generateKodeBatch();
        
        JTextField txtKodeBatch = new JTextField(kodeBatch);
        txtKodeBatch.setEditable(false); // Auto-generated, tidak bisa edit
        JTextField txtSupplier = new JTextField("Supplier Utama");
        JTextField txtHargaBeli = new JTextField("0");
        JTextField txtJumlah = new JTextField();
        JTextField txtTanggalMasuk = new JTextField(LocalDate.now().toString());
        JTextField txtTanggalKadaluarsa = new JTextField();
        JTextArea txtKeterangan = new JTextArea(3, 20);
        txtKeterangan.setLineWrap(true);
        txtKeterangan.setWrapStyleWord(true);

        panel.add(new JLabel("Menu:"));
        panel.add(new JLabel(namaMenu + " (" + idMenu + ")"));
        panel.add(new JLabel("Kode Batch:*"));
        panel.add(txtKodeBatch);
        panel.add(new JLabel("Supplier:*"));
        panel.add(txtSupplier);
        panel.add(new JLabel("Harga Beli:*"));
        panel.add(txtHargaBeli);
        panel.add(new JLabel("Jumlah:*"));
        panel.add(txtJumlah);
        panel.add(new JLabel("Tanggal Masuk:*"));
        panel.add(txtTanggalMasuk);
        panel.add(new JLabel("Tanggal Kadaluarsa:"));
        panel.add(txtTanggalKadaluarsa);
        panel.add(new JLabel("Keterangan:"));
        panel.add(new JScrollPane(txtKeterangan));
        
        // Info tambahan
        panel.add(new JLabel("Stok Sekarang:"));
        panel.add(new JLabel(stokSekarang + " pcs"));
        panel.add(new JLabel("Format Tanggal:"));
        panel.add(new JLabel("YYYY-MM-DD (contoh: 2024-12-31)"));

        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Tambah Stok Baru - " + namaMenu,
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try {
                // Validasi input
                String supplier = txtSupplier.getText().trim();
                String hargaBeliText = txtHargaBeli.getText().trim();
                String jumlahText = txtJumlah.getText().trim();
                String tanggalMasukText = txtTanggalMasuk.getText().trim();
                String tanggalKadaluarsaText = txtTanggalKadaluarsa.getText().trim();
                String keterangan = txtKeterangan.getText().trim();

                // Validasi field wajib
                if (supplier.isEmpty() || hargaBeliText.isEmpty() || jumlahText.isEmpty() || tanggalMasukText.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                            "Field bertanda * harus diisi!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double hargaBeli = Double.parseDouble(hargaBeliText);
                int jumlah = Integer.parseInt(jumlahText);
                LocalDate tanggalMasuk = LocalDate.parse(tanggalMasukText);

                if (jumlah <= 0) {
                    JOptionPane.showMessageDialog(this, 
                            "Jumlah harus lebih dari 0!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (hargaBeli < 0) {
                    JOptionPane.showMessageDialog(this,
                            "Harga beli tidak boleh negatif!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                LocalDate tanggalKadaluarsa = null;
                if (!tanggalKadaluarsaText.isEmpty()) {
                    tanggalKadaluarsa = LocalDate.parse(tanggalKadaluarsaText);
                    
                    // Validasi tanggal kadaluarsa tidak boleh sebelum tanggal masuk
                    if (tanggalKadaluarsa.isBefore(tanggalMasuk)) {
                        JOptionPane.showMessageDialog(this,
                                "Tanggal kadaluarsa tidak boleh sebelum tanggal masuk!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                System.out.println("🔧 Menyimpan stok baru...");
                System.out.println("   ID Menu: " + idMenu);
                System.out.println("   Kode Batch: " + kodeBatch);
                System.out.println("   Supplier: " + supplier);
                System.out.println("   Harga Beli: " + hargaBeli);
                System.out.println("   Jumlah: " + jumlah);
                System.out.println("   Tanggal Masuk: " + tanggalMasuk);
                System.out.println("   Tanggal Kadaluarsa: " + tanggalKadaluarsa);

                // Simpan stok baru
                boolean success = stokService.tambahStok(
                    idMenu, jumlah, tanggalMasuk, tanggalKadaluarsa, 
                    supplier, hargaBeli, keterangan
                );

                if (success) {
                    JOptionPane.showMessageDialog(this,
                            "✅ Stok berhasil ditambahkan!\n\n" +
                            "Menu: " + namaMenu + "\n" +
                            "Batch: " + kodeBatch + "\n" +
                            "Jumlah: +" + jumlah + " pcs\n" +
                            "Stok Total: " + (stokSekarang + jumlah) + " pcs",
                            "Success", JOptionPane.INFORMATION_MESSAGE);

                    loadDataMenu(); // Refresh table
                } else {
                    JOptionPane.showMessageDialog(this,
                            "❌ Gagal menambah stok!\nPeriksa koneksi database.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                        "❌ Format angka tidak valid!\n" +
                        "Harga beli dan jumlah harus berupa angka.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "❌ Error: " + e.getMessage() + "\n" +
                        "Pastikan format tanggal: YYYY-MM-DD",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ✅ METHOD LIHAT DETAIL STOK PER BATCH
    private void lihatDetailStok() {
        int selectedRow = tableMenu.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Pilih menu terlebih dahulu!",
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idMenu = (String) tableModel.getValueAt(selectedRow, 0);
        String namaMenu = (String) tableModel.getValueAt(selectedRow, 1);

        // Ambil detail stok dari database
        List<Stok> detailStok = stokService.getStokByMenu(idMenu);
        
        if (detailStok.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Tidak ada data stok untuk menu: " + namaMenu,
                    "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Tampilkan dalam dialog
        StringBuilder sb = new StringBuilder();
        sb.append("📦 DETAIL STOK - ").append(namaMenu).append("\n");
        sb.append("========================================\n\n");

        int totalAktif = 0;
        int totalExpired = 0;

        for (Stok stok : detailStok) {
            sb.append("🔸 Batch: ").append(stok.getKodeBatch()).append("\n");
            sb.append("   Supplier: ").append(stok.getSupplier()).append("\n");
            sb.append("   Jumlah: ").append(stok.getJumlah()).append(" pcs\n");
            sb.append("   Harga Beli: Rp ").append(String.format("%,.0f", stok.getHargaBeli())).append("\n");
            sb.append("   Tanggal Masuk: ").append(stok.getTanggalMasuk()).append("\n");
            
            if (stok.getTanggalKadaluarsa() != null) {
                sb.append("   Expired: ").append(stok.getTanggalKadaluarsa());
                if (stok.isExpired()) {
                    sb.append(" ⚠️ EXPIRED");
                    totalExpired += stok.getJumlah();
                } else if (stok.isHampirExpired()) {
                    sb.append(" ⚠️ HAMPIR EXPIRED");
                }
                sb.append("\n");
            }
            
            sb.append("   Status: ").append(stok.getStatus()).append("\n");
            
            if (stok.getKeterangan() != null && !stok.getKeterangan().isEmpty()) {
                sb.append("   Keterangan: ").append(stok.getKeterangan()).append("\n");
            }
            
            sb.append("   ---------------------------------\n");

            if ("AKTIF".equals(stok.getStatus()) && !stok.isExpired()) {
                totalAktif += stok.getJumlah();
            }
        }

        sb.append("\n📊 SUMMARY:\n");
        sb.append("   Total Stok Aktif: ").append(totalAktif).append(" pcs\n");
        sb.append("   Total Stok Expired: ").append(totalExpired).append(" pcs\n");
        sb.append("   Total Batch: ").append(detailStok.size()).append(" batch\n");

        JTextArea textArea = new JTextArea(sb.toString(), 20, 50);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        JOptionPane.showMessageDialog(this, scrollPane, 
            "Detail Stok - " + namaMenu, 
            JOptionPane.INFORMATION_MESSAGE);
    }

    // TEST METHOD
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuService menuService = new MenuService();
            new StokManagementForm(menuService).setVisible(true);
        });
    }
}