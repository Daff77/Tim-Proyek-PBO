/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author Daffa Danendra
 */

import service.MenuService;
import model.Menu;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 * @author Daffa Danendra
 */
public class MenuForm extends javax.swing.JFrame {

    private MenuService menuService;
    private boolean isAdmin;
    private JTable tableMenu;
    private DefaultTableModel tableModel;
    private JTextField txtPencarian;
    private JComboBox<String> comboKategori;
    private JButton btnCari;
    private JButton btnReset;

    // CONSTRUCTOR BARU yang menerima parameter
    public MenuForm(MenuService menuService, boolean isAdmin) {
        this.menuService = menuService;
        this.isAdmin = isAdmin;
        initComponents();
        setupTableModel();
        setupPencarianPanel();
        loadDataMenu();
        updateUIForRole();
    }

    // CONSTRUCTOR LAMA (default)
    public MenuForm() {
        this.menuService = new MenuService();
        this.isAdmin = false;
        initComponents();
        setupTableModel();
        setupPencarianPanel();
        loadDataMenu();
        updateUIForRole();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableMenu = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        btnRefresh = new javax.swing.JButton();
        btnTutup = new javax.swing.JButton();
        btnTambahMenu = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Daftar Menu - Cafe Management System");
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.BorderLayout());

        tableMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Menu", "Nama Menu", "Harga", "Kategori"
            }
        ));
        jScrollPane1.setViewportView(tableMenu);

        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnTutup.setText("Tutup");
        btnTutup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTutupActionPerformed(evt);
            }
        });

        btnTambahMenu.setText("Tambah Menu");
        btnTambahMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(btnRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnTutup)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnTambahMenu)
                .addContainerGap(157, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRefresh)
                    .addComponent(btnTutup)
                    .addComponent(btnTambahMenu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnTutupActionPerformed(java.awt.event.ActionEvent evt) {                                         
        this.dispose();
    }                                        

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {                                           
        loadDataMenu();
    }                                          

    private void btnTambahMenuActionPerformed(java.awt.event.ActionEvent evt) {                                              
        tambahMenu();
    }                                             

    // ✅ SETUP TABLE MODEL
    private void setupTableModel() {
        String[] columnNames = {"ID Menu", "Nama Menu", "Harga", "Kategori"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tableMenu.setModel(tableModel);
        
        // Set column widths
        tableMenu.getColumnModel().getColumn(0).setPreferredWidth(80);
        tableMenu.getColumnModel().getColumn(1).setPreferredWidth(200);
        tableMenu.getColumnModel().getColumn(2).setPreferredWidth(100);
        tableMenu.getColumnModel().getColumn(3).setPreferredWidth(150);
        
        tableMenu.setRowHeight(25);
        tableMenu.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
    }

    // ✅ SETUP PANEL PENCARIAN
    private void setupPencarianPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        searchPanel.setBackground(Color.WHITE);

        // Label pencarian
        searchPanel.add(new JLabel("🔍 Cari:"));

        // TextField pencarian
        txtPencarian = new JTextField(20);
        txtPencarian.setToolTipText("Cari berdasarkan nama menu, kategori, atau ID");
        
        // Enter key listener untuk pencarian
        txtPencarian.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    cariMenu();
                }
            }
        });
        searchPanel.add(txtPencarian);

        // ComboBox kategori
        searchPanel.add(new JLabel("Kategori:"));
        String[] kategoriOptions = {"Semua Kategori", "Minuman", "Makanan", "Snack", "Dessert", "Kopi", "Teh", "Jus", "Lainnya"};
        comboKategori = new JComboBox<>(kategoriOptions);
        comboKategori.addActionListener(e -> filterByKategori());
        searchPanel.add(comboKategori);

        // Tombol cari
        btnCari = new JButton("Cari");
        btnCari.addActionListener(e -> cariMenu());
        searchPanel.add(btnCari);

        // Tombol reset
        btnReset = new JButton("Reset");
        btnReset.addActionListener(e -> {
            txtPencarian.setText("");
            comboKategori.setSelectedIndex(0);
            loadDataMenu();
        });
        searchPanel.add(btnReset);

        // Tambah panel pencarian ke frame
        getContentPane().add(searchPanel, BorderLayout.NORTH);
    }

    // ✅ METHOD PENCARIAN MENU
    private void cariMenu() {
        String keyword = txtPencarian.getText().trim();
        String kategori = (String) comboKategori.getSelectedItem();
        
        tableModel.setRowCount(0);
        List<Menu> hasilPencarian;

        if ("Semua Kategori".equals(kategori) && keyword.isEmpty()) {
            // Tampilkan semua menu
            hasilPencarian = menuService.getAllMenu();
        } else if (!"Semua Kategori".equals(kategori) && keyword.isEmpty()) {
            // Filter by kategori saja
            hasilPencarian = menuService.getMenuByKategori(kategori);
        } else if ("Semua Kategori".equals(kategori) && !keyword.isEmpty()) {
            // Cari by keyword saja
            hasilPencarian = menuService.cariMenu(keyword);
        } else {
            // Cari by keyword dan filter by kategori
            List<Menu> hasilByKeyword = menuService.cariMenu(keyword);
            hasilPencarian = hasilByKeyword.stream()
                    .filter(menu -> menu.getKategori().equals(kategori))
                    .toList();
        }

        // Populate table dengan hasil pencarian
        for (Menu menu : hasilPencarian) {
            Object[] rowData = {
                menu.getIdMenu(),
                menu.getNamaMenu(),
                menuService.formatHarga(menu.getHarga()),
                menu.getKategori()
            };
            tableModel.addRow(rowData);
        }

        // Update title dengan info pencarian
        String searchInfo = "";
        if (!keyword.isEmpty()) {
            searchInfo += "Pencarian: '" + keyword + "' ";
        }
        if (!"Semua Kategori".equals(kategori)) {
            searchInfo += "Kategori: " + kategori + " ";
        }
        
        if (!searchInfo.isEmpty()) {
            setTitle("Daftar Menu - " + hasilPencarian.size() + " hasil (" + searchInfo.trim() + ")");
        } else {
            setTitle("Daftar Menu - " + hasilPencarian.size() + " items");
        }

        System.out.println("🔍 Pencarian selesai: " + hasilPencarian.size() + " hasil ditemukan");
    }

    // ✅ METHOD FILTER BY KATEGORI
    private void filterByKategori() {
        cariMenu(); // Reuse search method
    }

    // ✅ LOAD DATA MENU
    private void loadDataMenu() {
        tableModel.setRowCount(0);
        List<Menu> menuList = menuService.getAllMenu();

        for (Menu menu : menuList) {
            Object[] rowData = {
                menu.getIdMenu(),
                menu.getNamaMenu(),
                menuService.formatHarga(menu.getHarga()),
                menu.getKategori()
            };
            tableModel.addRow(rowData);
        }

        String roleInfo = isAdmin ? " (Admin Mode)" : " (Kasir Mode)";
        setTitle("Daftar Menu - " + menuList.size() + " items" + roleInfo);

        System.out.println("✅ Loaded " + menuList.size() + " menu items");
    }

    // ✅ UPDATE UI BERDASARKAN ROLE
    private void updateUIForRole() {
        if (!isAdmin) {
            btnTambahMenu.setVisible(false);
            setTitle("Daftar Menu - View Only");
        } else {
            setTitle("Daftar Menu - Admin Mode");
        }
    }

    // ✅ METHOD TAMBAH MENU (HANYA UNTUK ADMIN)
    private void tambahMenu() {
        if (!isAdmin) {
            JOptionPane.showMessageDialog(this,
                    "Hanya admin yang bisa menambah menu!",
                    "Access Denied",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));

        JTextField txtNama = new JTextField(20);
        JTextField txtHarga = new JTextField(10);
        
        // ✅ COMBO BOX UNTUK KATEGORI (BUKAN TEXTFIELD)
        String[] kategoriOptions = {"Minuman", "Makanan", "Snack", "Dessert", "Kopi", "Teh", "Jus", "Lainnya"};
        JComboBox<String> comboKategoriInput = new JComboBox<>(kategoriOptions);

        panel.add(new JLabel("Nama Menu:"));
        panel.add(txtNama);
        panel.add(new JLabel("Harga:"));
        panel.add(txtHarga);
        panel.add(new JLabel("Kategori:"));
        panel.add(comboKategoriInput); // ✅ COMBO BOX, BUKAN TEXTFIELD

        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Tambah Menu Baru",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String nama = txtNama.getText().trim();
            String hargaText = txtHarga.getText().trim();
            String kategori = (String) comboKategoriInput.getSelectedItem(); // ✅ AMBIL DARI COMBO BOX

            // Validasi input
            if (nama.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nama menu harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (hargaText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Harga harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double harga = Double.parseDouble(hargaText);
                if (harga <= 0) {
                    JOptionPane.showMessageDialog(this, "Harga harus lebih dari 0!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                System.out.println("🔧 Mencoba menambah menu...");
                boolean success = menuService.tambahMenu(nama, harga, kategori);

                if (success) {
                    JOptionPane.showMessageDialog(this,
                            "Menu '" + nama + "' berhasil ditambahkan!",
                            "Sukses",
                            JOptionPane.INFORMATION_MESSAGE);
                    loadDataMenu(); // Refresh table
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Gagal menambahkan menu. Cek console untuk detail error.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                        "Harga harus berupa angka!\nContoh: 10000",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            // Test sebagai admin
            MenuService menuService = new MenuService();
            new MenuForm(menuService, true).setVisible(true);
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnTambahMenu;
    private javax.swing.JButton btnTutup;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration                   
}
