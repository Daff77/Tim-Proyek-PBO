/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author Daffa Danendra
 */
/*
 * KELOLA STOK EXPIRED FORM
 */
import service.StokService;
import model.Stok;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class KelolaStokExpiredForm extends JFrame {

    private StokService stokService;
    private JTable tableStok;
    private DefaultTableModel tableModel;

    public KelolaStokExpiredForm() {
        this.stokService = new StokService();
        initUI();
        loadDataStokExpired();
    }

    private void initUI() {
        setTitle("Kelola Stok Expired - Cafe Management System");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel lblTitle = new JLabel("🗑️ KELOLA STOK EXPIRED", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitle.setForeground(Color.RED);
        lblTitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        // Table untuk stok expired
        String[] columnNames = {"ID Stok", "ID Menu", "Tanggal Masuk", "Tanggal Expired", "Jumlah", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableStok = new JTable(tableModel);
        tableStok.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableStok.setRowHeight(25);
        tableStok.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));

        JScrollPane scrollPane = new JScrollPane(tableStok);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Panel tombol aksi
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton btnHapus = new JButton("🗑️ Hapus Stok Expired");
        btnHapus.setBackground(Color.RED);
        btnHapus.setForeground(Color.WHITE);
        btnHapus.addActionListener(e -> hapusStokExpired());

        JButton btnRefresh = new JButton("🔄 Refresh");
        btnRefresh.addActionListener(e -> loadDataStokExpired());

        JButton btnLaporan = new JButton("📊 Laporan Wastage");
        btnLaporan.setBackground(new Color(139, 0, 0));
        btnLaporan.setForeground(Color.WHITE);
        btnLaporan.addActionListener(e -> tampilkanLaporanWastage());

        JButton btnTutup = new JButton("Tutup");
        btnTutup.addActionListener(e -> dispose());

        buttonPanel.add(btnHapus);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnLaporan);
        buttonPanel.add(btnTutup);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void loadDataStokExpired() {
        tableModel.setRowCount(0);
        List<Stok> stokExpired = stokService.getStokExpired();

        for (Stok stok : stokExpired) {
            Object[] rowData = {
                stok.getIdStok(),
                stok.getIdMenu(),
                stok.getTanggalMasuk(),
                stok.getTanggalKadaluarsa(),
                stok.getJumlah(),
                stok.getStatus()
            };
            tableModel.addRow(rowData);
        }

        setTitle("Kelola Stok Expired - " + stokExpired.size() + " items");
        
        if (stokExpired.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Tidak ada stok expired saat ini! 🎉", 
                "Info", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void hapusStokExpired() {
        int selectedRow = tableStok.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Pilih stok yang akan dihapus!");
            return;
        }

        String idStok = (String) tableModel.getValueAt(selectedRow, 0);
        String idMenu = (String) tableModel.getValueAt(selectedRow, 1);
        int jumlah = (Integer) tableModel.getValueAt(selectedRow, 4);

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Yakin ingin menghapus stok expired?\n\n" +
            "ID Stok: " + idStok + "\n" +
            "ID Menu: " + idMenu + "\n" +
            "Jumlah: " + jumlah + " pcs\n\n" +
            "Tindakan ini tidak dapat dibatalkan!",
            "Konfirmasi Hapus Stok Expired",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = stokService.hapusStokExpired(idStok);
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Stok expired berhasil dihapus!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadDataStokExpired();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Gagal menghapus stok expired!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void tampilkanLaporanWastage() {
        // Form pilih periode
        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));

        JTextField txtStartDate = new JTextField(LocalDate.now().withDayOfMonth(1).toString());
        JTextField txtEndDate = new JTextField(LocalDate.now().toString());

        panel.add(new JLabel("Tanggal Mulai:"));
        panel.add(txtStartDate);
        panel.add(new JLabel("Tanggal Akhir:"));
        panel.add(txtEndDate);
        panel.add(new JLabel("Format:"));
        panel.add(new JLabel("YYYY-MM-DD (contoh: 2024-01-01)"));

        int result = JOptionPane.showConfirmDialog(
            this,
            panel,
            "Laporan Wastage - Pilih Periode",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try {
                LocalDate startDate = LocalDate.parse(txtStartDate.getText().trim());
                LocalDate endDate = LocalDate.parse(txtEndDate.getText().trim());

                List<Stok> wastage = stokService.getLaporanWastage(startDate, endDate);
                
                // Tampilkan laporan
                StringBuilder laporan = new StringBuilder();
                laporan.append("📊 LAPORAN WASTAGE\n");
                laporan.append("Periode: ").append(startDate).append(" s/d ").append(endDate).append("\n");
                laporan.append("=================================\n");
                
                int totalItem = 0;
                double totalNilai = 0;
                
                for (Stok stok : wastage) {
                    laporan.append(String.format("- %s: %d pcs (Exp: %s)\n", 
                        stok.getIdMenu(), stok.getJumlah(), stok.getTanggalKadaluarsa()));
                    totalItem += stok.getJumlah();
                    // totalNilai += ... // bisa hitung nilai jika ada harga beli
                }
                
                laporan.append("=================================\n");
                laporan.append("Total Item Expired: ").append(totalItem).append(" pcs\n");
                laporan.append("Total Stok Record: ").append(wastage.size()).append(" entries\n");
                
                JOptionPane.showMessageDialog(this,
                    laporan.toString(),
                    "Laporan Wastage",
                    JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error: Format tanggal tidak valid!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new KelolaStokExpiredForm().setVisible(true);
        });
    }
}