/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Pesanan;
import model.DetailPesanan;
import model.Menu;
import util.DatabaseConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PesananDAO {

    public PesananDAO() {
        // Tidak perlu check constraint lagi karena sudah dihapus
    }

    // Method untuk generate ID manual
    private String generatePesananId() {
        String sql = "SELECT COALESCE(MAX(CAST(SUBSTRING(id_pesanan FROM 4) AS INTEGER)), 0) + 1 as next_id FROM pesanan";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                int nextId = rs.getInt("next_id");
                return "PSN" + String.format("%03d", nextId);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error generate pesanan ID: " + e.getMessage());
        }

        return "PSN001";
    }

    private String generateDetailId() {
        String sql = "SELECT COALESCE(MAX(CAST(SUBSTRING(id_detail FROM 4) AS INTEGER)), 0) + 1 as next_id FROM detail_pesanan";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                int nextId = rs.getInt("next_id");
                return "DET" + String.format("%03d", nextId);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error generate detail ID: " + e.getMessage());
        }

        return "DET001";
    }

    // ✅ UPDATE METHOD CREATE PESANAN - TANPA UPDATE STOK LAMA
    public boolean createPesanan(Pesanan pesanan) {
        String sqlPesanan = "INSERT INTO pesanan (id_pesanan, id_pengguna, tanggal_pesanan, total, status, no_meja) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlDetail = "INSERT INTO detail_pesanan (id_detail, id_pesanan, id_menu, jumlah, subtotal) VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;

        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Generate manual ID
            String pesananId = generatePesananId();
            pesanan.setIdPesanan(pesananId);

            System.out.println("🔧 Creating pesanan with ID: " + pesananId);

            PreparedStatement pstmtPesanan = conn.prepareStatement(sqlPesanan);
            pstmtPesanan.setString(1, pesananId);
            pstmtPesanan.setString(2, pesanan.getIdPengguna());
            
            // ✅ PASTIKAN TANGGAL TIDAK NULL
            LocalDateTime tanggal = pesanan.getTanggalPesanan();
            if (tanggal == null) {
                tanggal = LocalDateTime.now();
            }
            pstmtPesanan.setTimestamp(3, Timestamp.valueOf(tanggal));
            
            pstmtPesanan.setDouble(4, pesanan.getTotal());
            pstmtPesanan.setString(5, pesanan.getStatus());
            pstmtPesanan.setInt(6, pesanan.getNoMeja());

            System.out.println("🔧 Using tanggal: '" + tanggal + "'");

            int affectedRows = pstmtPesanan.executeUpdate();
            pstmtPesanan.close();

            if (affectedRows == 0) {
                throw new SQLException("❌ Creating pesanan failed.");
            }

            System.out.println("✅ Pesanan created with tanggal: '" + tanggal + "'");

            // STEP 2: Insert detail pesanan
            PreparedStatement pstmtDetail = conn.prepareStatement(sqlDetail);
            int detailCount = 0;

            for (DetailPesanan detail : pesanan.getDetailPesananList()) {
                String detailId = generateDetailId();
                pstmtDetail.setString(1, detailId);
                pstmtDetail.setString(2, pesananId);
                pstmtDetail.setString(3, detail.getIdMenu());
                pstmtDetail.setInt(4, detail.getJumlah());
                pstmtDetail.setDouble(5, detail.getSubtotal());
                pstmtDetail.addBatch();
                detailCount++;
            }

            pstmtDetail.executeBatch();
            pstmtDetail.close();
            System.out.println("✅ Detail pesanan inserted: " + detailCount + " items");

            // ✅ STEP 3: STOK SEKARANG DIKELOLA OLEH STOKSERVICE DI TRANSAKSISERVICE
            // Tidak perlu update stok di sini lagi

            conn.commit();
            System.out.println("🎉 TRANSACTION SUCCESSFUL! Pesanan ID: " + pesananId);
            return true;

        } catch (SQLException e) {
            System.out.println("❌ Transaction failed: " + e.getMessage());

            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException ex) {
                System.out.println("❌ Rollback failed: " + ex.getMessage());
            }
            return false;
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("❌ Error closing connection: " + e.getMessage());
            }
        }
    }

    // ✅ HAPUS METHOD UPDATE STOK LAMA
    // private void updateStokMenu(List<DetailPesanan> details, Connection conn) throws SQLException {
    //     // Method ini sudah tidak digunakan, dihandle oleh StokService
    // }

    // Method untuk mendapatkan detail pesanan
    public List<DetailPesanan> getDetailPesanan(String idPesanan) {
        List<DetailPesanan> details = new ArrayList<>();
        String sql = "SELECT dp.*, m.nama_menu, m.harga FROM detail_pesanan dp " +
                    "JOIN menu m ON dp.id_menu = m.id_menu " +
                    "WHERE dp.id_pesanan = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, idPesanan);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                DetailPesanan detail = new DetailPesanan();
                detail.setIdDetail(rs.getString("id_detail"));
                detail.setIdPesanan(rs.getString("id_pesanan"));
                detail.setIdMenu(rs.getString("id_menu"));
                detail.setJumlah(rs.getInt("jumlah"));
                detail.setSubtotal(rs.getDouble("subtotal"));
                
                // Buat object menu
                Menu menu = new Menu();
                menu.setIdMenu(rs.getString("id_menu"));
                menu.setNamaMenu(rs.getString("nama_menu"));
                menu.setHarga(rs.getDouble("harga"));
                detail.setMenu(menu);
                
                details.add(detail);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error get detail pesanan: " + e.getMessage());
        }

        return details;
    }

    // Method untuk mendapatkan semua pesanan
    public List<Pesanan> getAllPesanan() {
        List<Pesanan> pesananList = new ArrayList<>();
        String sql = "SELECT p.*, pg.nama_pengguna FROM pesanan p " +
                    "JOIN pengguna pg ON p.id_pengguna = pg.id_pengguna " +
                    "ORDER BY p.tanggal_pesanan DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Pesanan pesanan = new Pesanan();
                pesanan.setIdPesanan(rs.getString("id_pesanan"));
                pesanan.setIdPengguna(rs.getString("id_pengguna"));
                pesanan.setTanggalPesanan(rs.getTimestamp("tanggal_pesanan").toLocalDateTime());
                pesanan.setTotal(rs.getDouble("total"));
                pesanan.setStatus(rs.getString("status"));
                pesanan.setNoMeja(rs.getInt("no_meja"));
                
                // Get detail pesanan
                List<DetailPesanan> details = getDetailPesanan(pesanan.getIdPesanan());
                pesanan.setDetailPesananList(details);
                
                pesananList.add(pesanan);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error get all pesanan: " + e.getMessage());
        }

        return pesananList;
    }
}