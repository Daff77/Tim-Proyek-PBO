/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Daffa Danendra
 */
import util.DatabaseConnection;
import model.Stok;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StokDAO {
    
    public boolean simpanStok(Stok stok) {
        String sql = "INSERT INTO stok (id_stok, id_menu, kode_batch, supplier, harga_beli, jumlah, tanggal_masuk, tanggal_kadaluarsa, status, keterangan) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, generateStokId());
            pstmt.setString(2, stok.getIdMenu());
            pstmt.setString(3, stok.getKodeBatch());
            pstmt.setString(4, stok.getSupplier());
            pstmt.setDouble(5, stok.getHargaBeli());
            pstmt.setInt(6, stok.getJumlah());
            pstmt.setDate(7, Date.valueOf(stok.getTanggalMasuk()));
            
            // Tanggal kadaluarsa bisa null
            if (stok.getTanggalKadaluarsa() != null) {
                pstmt.setDate(8, Date.valueOf(stok.getTanggalKadaluarsa()));
            } else {
                pstmt.setNull(8, Types.DATE);
            }
            
            pstmt.setString(9, stok.getStatus());
            pstmt.setString(10, stok.getKeterangan());
            
            boolean result = pstmt.executeUpdate() > 0;
            if (result) {
                System.out.println("✅ Stok berhasil disimpan - Batch: " + stok.getKodeBatch());
            }
            return result;
            
        } catch (SQLException e) {
            System.out.println("❌ Error simpan stok: " + e.getMessage());
            return false;
        }
    }
    
    public List<Stok> getStokByMenu(String idMenu) {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.id_menu = ? " +
                    "ORDER BY s.tanggal_kadaluarsa ASC NULLS LAST, s.tanggal_masuk ASC, s.kode_batch";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, idMenu);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok by menu: " + e.getMessage());
        }
        
        return result;
    }
    
    public List<Stok> getStokAktif() {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.status = 'AKTIF' " +
                    "ORDER BY s.tanggal_kadaluarsa ASC NULLS LAST, s.tanggal_masuk ASC, s.kode_batch";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok aktif: " + e.getMessage());
        }
        
        return result;
    }
    
    public List<Stok> getStokAktifByMenu(String idMenu) {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.id_menu = ? AND s.status = 'AKTIF' " +
                    "ORDER BY s.tanggal_kadaluarsa ASC NULLS LAST, s.tanggal_masuk ASC, s.kode_batch";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, idMenu);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok aktif by menu: " + e.getMessage());
        }
        
        return result;
    }
    
    public List<Stok> getStokHampirExpired() {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.status = 'AKTIF' AND s.tanggal_kadaluarsa IS NOT NULL " +
                    "AND s.tanggal_kadaluarsa BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '7 days' " +
                    "ORDER BY s.tanggal_kadaluarsa ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok hampir expired: " + e.getMessage());
        }
        
        return result;
    }
    
    public List<Stok> getStokExpired() {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.status = 'AKTIF' AND s.tanggal_kadaluarsa IS NOT NULL " +
                    "AND s.tanggal_kadaluarsa < CURRENT_DATE " +
                    "ORDER BY s.tanggal_kadaluarsa ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok expired: " + e.getMessage());
        }
        
        return result;
    }
    
    public boolean updateStatusStok(String idStok, String status) {
        String sql = "UPDATE stok SET status = ? WHERE id_stok = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            pstmt.setString(2, idStok);
            
            boolean result = pstmt.executeUpdate() > 0;
            if (result) {
                System.out.println("✅ Status stok updated: " + idStok + " -> " + status);
            }
            return result;
            
        } catch (SQLException e) {
            System.out.println("❌ Error update status stok: " + e.getMessage());
            return false;
        }
    }
    
    public boolean kurangiStok(String idStok, int jumlah) {
        String sql = "UPDATE stok SET jumlah = jumlah - ? WHERE id_stok = ? AND jumlah >= ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, jumlah);
            pstmt.setString(2, idStok);
            pstmt.setInt(3, jumlah);
            
            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                System.out.println("✅ Stok dikurangi: " + idStok + " -" + jumlah);
                
                // Cek jika stok habis, update status
                String checkSql = "SELECT jumlah FROM stok WHERE id_stok = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setString(1, idStok);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next() && rs.getInt("jumlah") == 0) {
                    updateStatusStok(idStok, "HABIS");
                    System.out.println("🔄 Status diupdate ke HABIS: " + idStok);
                }
                checkStmt.close();
            }
            
            return affected > 0;
            
        } catch (SQLException e) {
            System.out.println("❌ Error kurangi stok: " + e.getMessage());
            return false;
        }
    }
    
    public Stok getStokById(String idStok) {
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.id_stok = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, idStok);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToStok(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    public Stok getStokByBatch(String kodeBatch) {
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.kode_batch = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, kodeBatch);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToStok(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok by batch: " + e.getMessage());
        }
        
        return null;
    }
    
    public boolean isKodeBatchExists(String kodeBatch) {
        String sql = "SELECT COUNT(*) FROM stok WHERE kode_batch = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, kodeBatch);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error check kode batch: " + e.getMessage());
        }
        
        return false;
    }
    
    public List<Stok> getStokBySupplier(String supplier) {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.supplier = ? " +
                    "ORDER BY s.tanggal_masuk DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, supplier);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok by supplier: " + e.getMessage());
        }
        
        return result;
    }
    
    // ✅ METHOD BARU: Get stok yang akan expired dalam range tertentu
    public List<Stok> getStokAkanExpired(int hariSebelumExpired) {
        List<Stok> result = new ArrayList<>();
        String sql = "SELECT s.*, m.nama_menu FROM stok s " +
                    "JOIN menu m ON s.id_menu = m.id_menu " +
                    "WHERE s.status = 'AKTIF' AND s.tanggal_kadaluarsa IS NOT NULL " +
                    "AND s.tanggal_kadaluarsa BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '" + hariSebelumExpired + " days' " +
                    "ORDER BY s.tanggal_kadaluarsa ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Stok stok = mapResultSetToStok(rs);
                result.add(stok);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error get stok akan expired: " + e.getMessage());
        }
        
        return result;
    }
    
    private Stok mapResultSetToStok(ResultSet rs) throws SQLException {
        Stok stok = new Stok();
        stok.setIdStok(rs.getString("id_stok"));
        stok.setIdMenu(rs.getString("id_menu"));
        stok.setKodeBatch(rs.getString("kode_batch"));
        stok.setSupplier(rs.getString("supplier"));
        stok.setHargaBeli(rs.getDouble("harga_beli"));
        stok.setJumlah(rs.getInt("jumlah"));
        stok.setTanggalMasuk(rs.getDate("tanggal_masuk").toLocalDate());
        
        Date kadaluarsa = rs.getDate("tanggal_kadaluarsa");
        if (kadaluarsa != null) {
            stok.setTanggalKadaluarsa(kadaluarsa.toLocalDate());
        }
        
        stok.setStatus(rs.getString("status"));
        stok.setKeterangan(rs.getString("keterangan"));
        return stok;
    }
    
    private String generateStokId() {
        String sql = "SELECT COALESCE(MAX(CAST(SUBSTRING(id_stok FROM 4) AS INTEGER)), 0) + 1 as next_id FROM stok";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                int nextId = rs.getInt("next_id");
                return "STK" + String.format("%03d", nextId);
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error generate stok ID: " + e.getMessage());
        }
        
        return "STK001";
    }
    
    public String generateKodeBatch() {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String random = String.valueOf((int)(Math.random() * 1000));
        return "BATCH-" + timestamp + "-" + random;
    }
}