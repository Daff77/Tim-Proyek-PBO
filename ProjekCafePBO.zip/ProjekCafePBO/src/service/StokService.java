/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author Daffa Danendra
 */
import dao.StokDAO;
import model.Stok;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class StokService {
    private StokDAO stokDAO;
    
    public StokService() {
        this.stokDAO = new StokDAO();
        autoCheckExpiredStok(); // ✅ AUTO CHECK SETIAP KALI SERVICE DIBUAT
    }
    
    // ✅ METHOD UNTUK AUTO CHECK & UPDATE STOK EXPIRED
    public void autoCheckExpiredStok() {
        List<Stok> expiredStok = stokDAO.getStokExpired();
        
        for (Stok stok : expiredStok) {
            System.out.println("⚠️ STOK EXPIRED: " + stok.getKodeBatch() + 
                             " | Menu: " + stok.getIdMenu() + 
                             " | Expired: " + stok.getTanggalKadaluarsa());
            
            // Auto update status menjadi EXPIRED
            stokDAO.updateStatusStok(stok.getIdStok(), "EXPIRED");
        }
        
        if (!expiredStok.isEmpty()) {
            System.out.println("🔔 " + expiredStok.size() + " stok item telah expired dan diupdate statusnya");
        }
    }
    
    // ✅ METHOD UNTUK MENDAPATKAN STOK YANG BISA DIPAKAI (NON-EXPIRED) - DENGAN BATCH
    public List<Stok> getStokAvailableForUse(String idMenu) {
        List<Stok> semuaStok = stokDAO.getStokAktifByMenu(idMenu);
        List<Stok> stokTersedia = new ArrayList<>();
        
        for (Stok stok : semuaStok) {
            if ("AKTIF".equals(stok.getStatus()) && !stok.isExpired()) {
                stokTersedia.add(stok);
            }
        }
        
        // Urutkan berdasarkan FIFO: expired date dulu, lalu tanggal masuk
        stokTersedia.sort((s1, s2) -> {
            // Prioritaskan yang ada tanggal expired
            if (s1.getTanggalKadaluarsa() == null && s2.getTanggalKadaluarsa() == null) {
                return s1.getTanggalMasuk().compareTo(s2.getTanggalMasuk());
            }
            if (s1.getTanggalKadaluarsa() == null) return 1; // yang null di belakang
            if (s2.getTanggalKadaluarsa() == null) return -1; // yang null di belakang
            return s1.getTanggalKadaluarsa().compareTo(s2.getTanggalKadaluarsa());
        });
        
        return stokTersedia;
    }
    
    // ✅ METHOD UNTUK PAKAI STOK (FIFO - FIRST IN FIRST OUT) - DENGAN BATCH TRACKING
    public boolean pakaiStok(String idMenu, int jumlahDibutuhkan) {
        List<Stok> stokTersedia = getStokAvailableForUse(idMenu);
        
        if (stokTersedia.isEmpty()) {
            System.out.println("❌ Tidak ada stok tersedia untuk menu: " + idMenu);
            return false;
        }
        
        // Hitung total stok tersedia
        int totalTersedia = stokTersedia.stream().mapToInt(Stok::getJumlah).sum();
        if (totalTersedia < jumlahDibutuhkan) {
            System.out.println("❌ Stok tidak cukup. Butuh: " + jumlahDibutuhkan + ", Tersedia: " + totalTersedia);
            return false;
        }
        
        System.out.println("🔍 Pakai stok untuk menu: " + idMenu + 
                         " | Butuh: " + jumlahDibutuhkan + 
                         " | Tersedia: " + totalTersedia +
                         " | Batch tersedia: " + stokTersedia.size());
        
        int sisaKebutuhan = jumlahDibutuhkan;
        List<BatchUsage> batchUsage = new ArrayList<>();
        
        for (Stok stok : stokTersedia) {
            if (sisaKebutuhan <= 0) break;
            
            int jumlahPakai = Math.min(stok.getJumlah(), sisaKebutuhan);
            boolean success = stokDAO.kurangiStok(stok.getIdStok(), jumlahPakai);
            
            if (success) {
                sisaKebutuhan -= jumlahPakai;
                batchUsage.add(new BatchUsage(stok.getKodeBatch(), jumlahPakai, stok.getHargaBeli()));
                
                System.out.println("✅ Pakai stok batch: " + stok.getKodeBatch() + 
                                 " sebanyak " + jumlahPakai +
                                 " | Sisa kebutuhan: " + sisaKebutuhan);
            }
        }
        
        if (sisaKebutuhan == 0) {
            // Log penggunaan batch untuk tracking
            logBatchUsage(idMenu, batchUsage);
            return true;
        } else {
            System.out.println("❌ Gagal memenuhi kebutuhan stok. Sisa: " + sisaKebutuhan);
            return false;
        }
    }
    
    // ✅ METHOD UNTUK HAPUS/REMOVE STOK EXPIRED
    public boolean hapusStokExpired(String idStok) {
        Stok stok = getStokById(idStok);
        if (stok == null || !"EXPIRED".equals(stok.getStatus())) {
            System.out.println("❌ Stok tidak ditemukan atau bukan status EXPIRED");
            return false;
        }
        
        // Update status menjadi DIHAPUS (soft delete)
        return stokDAO.updateStatusStok(idStok, "DIHAPUS");
    }
    
    // ✅ METHOD UNTUK GET STOK BY ID
    public Stok getStokById(String idStok) {
        return stokDAO.getStokById(idStok);
    }
    
    // ✅ METHOD UNTUK GET STOK BY BATCH
    public Stok getStokByBatch(String kodeBatch) {
        return stokDAO.getStokByBatch(kodeBatch);
    }
    
    // ✅ METHOD BARU: Hitung harga pokok penjualan berdasarkan batch
    public double hitungHargaPokokPenjualan(String idMenu, int quantity) {
        List<Stok> stokTersedia = getStokAvailableForUse(idMenu);
        double totalCost = 0;
        int remaining = quantity;
        
        for (Stok batch : stokTersedia) {
            if (remaining <= 0) break;
            
            int used = Math.min(batch.getJumlah(), remaining);
            totalCost += used * batch.getHargaBeli();
            remaining -= used;
            
            System.out.println("💰 COGS - Batch: " + batch.getKodeBatch() + 
                             " | Used: " + used + 
                             " | Cost: " + (used * batch.getHargaBeli()));
        }
        
        System.out.println("💰 Total COGS untuk " + quantity + " pcs: Rp " + totalCost);
        return totalCost;
    }
    
    // ✅ METHOD BARU: Cek stok akan expired (untuk early warning)
    public List<Stok> getStokAkanExpired(int hariSebelumExpired) {
        return stokDAO.getStokAkanExpired(hariSebelumExpired);
    }
    
    // ✅ METHOD BARU: Get stok by supplier
    public List<Stok> getStokBySupplier(String supplier) {
        return stokDAO.getStokBySupplier(supplier);
    }
    
    // ✅ METHOD BARU: Generate kode batch
    public String generateKodeBatch() {
        return stokDAO.generateKodeBatch();
    }
    
    // ✅ METHOD BARU: Cek kode batch exists
    public boolean isKodeBatchExists(String kodeBatch) {
        return stokDAO.isKodeBatchExists(kodeBatch);
    }
    
    // ==================== METHOD-METHOD LAMA (COMPATIBILITY) ====================
    
    public boolean tambahStok(String idMenu, int jumlah, LocalDate tanggalMasuk, LocalDate tanggalKadaluarsa, 
                             String supplier, double hargaBeli, String keterangan) {
        String kodeBatch = generateKodeBatch();
        Stok stok = new Stok(idMenu, kodeBatch, supplier, hargaBeli, jumlah, tanggalMasuk, tanggalKadaluarsa, keterangan);
        return stokDAO.simpanStok(stok);
    }
    
    public boolean tambahStok(String idMenu, int jumlah, LocalDate tanggalMasuk, LocalDate tanggalKadaluarsa) {
        return tambahStok(idMenu, jumlah, tanggalMasuk, tanggalKadaluarsa, "Supplier Default", 0, null);
    }
    
    public boolean tambahStok(String idMenu, int jumlah, LocalDate tanggalMasuk) {
        return tambahStok(idMenu, jumlah, tanggalMasuk, null, "Supplier Default", 0, null);
    }
    
    public boolean tambahStok(String idMenu, int jumlah) {
        return tambahStok(idMenu, jumlah, LocalDate.now(), null, "Supplier Default", 0, null);
    }
    
    public List<Stok> getStokByMenu(String idMenu) {
        return stokDAO.getStokByMenu(idMenu);
    }
    
    public List<Stok> getStokAktif() {
        return stokDAO.getStokAktif();
    }
    
    public List<Stok> getStokHampirExpired() {
        return stokDAO.getStokHampirExpired();
    }
    
    public List<Stok> getStokExpired() {
        return stokDAO.getStokExpired();
    }
    
    public boolean kurangiStok(String idStok, int jumlah) {
        return stokDAO.kurangiStok(idStok, jumlah);
    }
    
    public boolean updateStatusStok(String idStok, String status) {
        return stokDAO.updateStatusStok(idStok, status);
    }
    
    public int getTotalStokTersedia(String idMenu) {
        List<Stok> stokList = stokDAO.getStokAktifByMenu(idMenu);
        return stokList.stream()
                .filter(stok -> "AKTIF".equals(stok.getStatus()) && !stok.isExpired())
                .mapToInt(Stok::getJumlah)
                .sum();
    }
    
    public List<Stok> getStokHampirHabis(int threshold) {
        List<Stok> semuaStok = stokDAO.getStokAktif();
        return semuaStok.stream()
                .filter(stok -> stok.getJumlah() <= threshold)
                .toList();
    }
    
    // ✅ METHOD BARU: Laporan wastage dengan detail batch
    public List<Stok> getLaporanWastage(LocalDate startDate, LocalDate endDate) {
        List<Stok> semuaStok = stokDAO.getStokExpired();
        return semuaStok.stream()
                .filter(stok -> !stok.getTanggalMasuk().isBefore(startDate) && 
                               !stok.getTanggalMasuk().isAfter(endDate))
                .toList();
    }
        
    // Inner class untuk tracking batch usage
    private static class BatchUsage {
        String kodeBatch;
        int jumlah;
        double hargaBeli;
        
        BatchUsage(String kodeBatch, int jumlah, double hargaBeli) {
            this.kodeBatch = kodeBatch;
            this.jumlah = jumlah;
            this.hargaBeli = hargaBeli;
        }
    }
    
    // Method untuk log penggunaan batch
    private void logBatchUsage(String idMenu, List<BatchUsage> batchUsage) {
        System.out.println("📋 BATCH USAGE LOG - Menu: " + idMenu);
        double totalCost = 0;
        
        for (BatchUsage usage : batchUsage) {
            double batchCost = usage.jumlah * usage.hargaBeli;
            totalCost += batchCost;
            System.out.println("   ├─ Batch: " + usage.kodeBatch + 
                             " | Qty: " + usage.jumlah + 
                             " | Cost: Rp " + batchCost);
        }
        
        System.out.println("   └─ TOTAL COST: Rp " + totalCost);
    }
}