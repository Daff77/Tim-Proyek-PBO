/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import dao.PesananDAO;
import dao.MenuDAO;
import model.Pesanan;
import model.DetailPesanan;
import model.Menu;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Daffa Danendra
 */
public class TransaksiService {

    private PesananDAO pesananDAO;
    private MenuDAO menuDAO;
    private StokService stokService;
    private List<DetailPesanan> keranjang;
    private String namaKasir;
    private int noMeja;

    // ✅ UPDATE CONSTRUCTOR DENGAN STOK SERVICE
    public TransaksiService(String namaKasir, int noMeja) {
        this.pesananDAO = new PesananDAO();
        this.menuDAO = new MenuDAO();
        this.stokService = new StokService(); // ✅ INISIALISASI STOK SERVICE
        this.keranjang = new ArrayList<>();
        this.namaKasir = namaKasir;
        this.noMeja = noMeja;
    }

    // ✅ CONSTRUCTOR LAMA (UNTUK COMPATIBILITY)
    public TransaksiService() {
        this.pesananDAO = new PesananDAO();
        this.menuDAO = new MenuDAO();
        this.stokService = new StokService();
        this.keranjang = new ArrayList<>();
        this.namaKasir = "Unknown";
        this.noMeja = 0;
    }

    // ✅ METHOD SETTER UNTUK NAMA KASIR
    public void setNamaKasir(String namaKasir) {
        this.namaKasir = namaKasir;
    }

    // ✅ METHOD TAMBAH KE KERANJANG DENGAN CEK STOK
    public boolean tambahKeKeranjang(String idMenu, int jumlah) {
        System.out.println("🔧 TRANSAKSI SERVICE: Tambah ke keranjang - ID: " + idMenu + ", Jumlah: " + jumlah);

        Menu menu = menuDAO.getMenuById(idMenu);
        if (menu == null) {
            System.out.println("❌ TRANSAKSI SERVICE: Menu tidak ditemukan");
            JOptionPane.showMessageDialog(null, "Menu tidak ditemukan!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // ✅ CEK STOK TERSEDIA DENGAN SISTEM BARU
        int stokTersedia = stokService.getTotalStokTersedia(idMenu);
        if (stokTersedia < jumlah) {
            System.out.println("❌ TRANSAKSI SERVICE: Stok tidak cukup");
            JOptionPane.showMessageDialog(null,
                    "Stok " + menu.getNamaMenu() + " tidak cukup!\nStok tersedia: " + stokTersedia,
                    "Stok Habis", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        System.out.println("🔧 TRANSAKSI SERVICE: Menu ditemukan - " + menu.getNamaMenu() + " | Stok tersedia: " + stokTersedia);

        // Cek apakah menu sudah ada di keranjang
        for (DetailPesanan detail : keranjang) {
            if (detail.getIdMenu().equals(idMenu)) {
                // Update jumlah dan subtotal
                int newJumlah = detail.getJumlah() + jumlah;
                
                // Cek lagi stok untuk jumlah baru
                if (stokTersedia < newJumlah) {
                    JOptionPane.showMessageDialog(null,
                            "Stok " + menu.getNamaMenu() + " tidak cukup untuk jumlah tersebut!\nStok tersedia: " + stokTersedia,
                            "Stok Habis", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
                
                detail.setJumlah(newJumlah);
                detail.setSubtotal(menu.getHarga() * newJumlah);
                System.out.println("✅ TRANSAKSI SERVICE: Update existing item, jumlah sekarang: " + newJumlah);
                return true;
            }
        }

        // Jika belum ada, tambah baru
        DetailPesanan detail = new DetailPesanan();
        detail.setIdMenu(idMenu);
        detail.setMenu(menu);
        detail.setJumlah(jumlah);
        detail.setSubtotal(menu.getHarga() * jumlah);
        keranjang.add(detail);

        System.out.println("✅ TRANSAKSI SERVICE: Item baru ditambahkan ke keranjang");
        System.out.println("🔧 TRANSAKSI SERVICE: Jumlah item di keranjang: " + keranjang.size());

        return true;
    }

    public boolean hapusDariKeranjang(String idMenu) {
        boolean removed = keranjang.removeIf(detail -> detail.getIdMenu().equals(idMenu));
        if (removed) {
            System.out.println("✅ Item dihapus dari keranjang: " + idMenu);
        }
        return removed;
    }

    public double getTotalKeranjang() {
        return keranjang.stream()
                .mapToDouble(DetailPesanan::getSubtotal)
                .sum();
    }

    public List<DetailPesanan> getKeranjang() {
        return new ArrayList<>(keranjang);
    }

    public void kosongkanKeranjang() {
        keranjang.clear();
        System.out.println("✅ Keranjang dikosongkan");
    }

    // ✅ UPDATE METHOD CHECKOUT DENGAN SISTEM STOK BARU
    public boolean checkout(String idPengguna) {
        if (keranjang.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Keranjang kosong!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        try {
            // ✅ CEK STOK FINAL SEBELUM PROSES
            if (!cekStokTersediaFinal()) {
                JOptionPane.showMessageDialog(null,
                        "Stok tidak mencukupi untuk beberapa item!\nSilakan periksa kembali keranjang.",
                        "Stok Tidak Cukup", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            // Buat object pesanan
            Pesanan pesanan = new Pesanan();
            pesanan.setIdPengguna(idPengguna);
            pesanan.setTotal(getTotalKeranjang());
            pesanan.setNoMeja(noMeja);
            
            // Convert keranjang ke detail pesanan
            List<DetailPesanan> detailsForPesanan = new ArrayList<>();
            for (DetailPesanan keranjangDetail : keranjang) {
                DetailPesanan pesananDetail = new DetailPesanan();
                pesananDetail.setIdMenu(keranjangDetail.getIdMenu());
                pesananDetail.setJumlah(keranjangDetail.getJumlah());
                pesananDetail.setSubtotal(keranjangDetail.getSubtotal());
                pesananDetail.setMenu(keranjangDetail.getMenu());
                detailsForPesanan.add(pesananDetail);
            }
            pesanan.setDetailPesananList(detailsForPesanan);

            System.out.println("🔧 Processing checkout dengan " + detailsForPesanan.size() + " items...");
            System.out.println("🔧 No Meja: " + noMeja);
            System.out.println("🔧 Kasir: " + namaKasir);

            // Proses pesanan
            boolean success = pesananDAO.createPesanan(pesanan);

            if (success) {
                // ✅ UPDATE STOK DENGAN SISTEM BARU
                boolean stokUpdated = updateStokMenuBaru(detailsForPesanan);
                
                if (stokUpdated) {
                    tampilkanStruk(pesanan, detailsForPesanan);
                    kosongkanKeranjang();
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Pesanan berhasil dicatat tapi ada masalah dengan update stok!\nSilakan hubungi administrator.",
                            "Warning", JOptionPane.WARNING_MESSAGE);
                    kosongkanKeranjang();
                    return true; // Pesanan tetap sukses dicatat
                }
            } else {
                JOptionPane.showMessageDialog(null, "Gagal memproses transaksi!", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // ✅ METHOD CEK STOK FINAL SEBELUM CHECKOUT
    private boolean cekStokTersediaFinal() {
        for (DetailPesanan detail : keranjang) {
            int stokTersedia = stokService.getTotalStokTersedia(detail.getIdMenu());
            if (stokTersedia < detail.getJumlah()) {
                System.out.println("❌ Stok tidak cukup: " + detail.getMenu().getNamaMenu() + 
                                 " (Butuh: " + detail.getJumlah() + ", Tersedia: " + stokTersedia + ")");
                return false;
            }
        }
        return true;
    }

    // ✅ METHOD UPDATE STOK DENGAN SISTEM BARU (FIFO)
    private boolean updateStokMenuBaru(List<DetailPesanan> details) {
        try {
            for (DetailPesanan detail : details) {
                boolean success = stokService.pakaiStok(detail.getIdMenu(), detail.getJumlah());
                if (!success) {
                    System.out.println("❌ Gagal update stok untuk menu: " + detail.getIdMenu());
                    // Tidak langsung return false, lanjut ke menu berikutnya
                } else {
                    System.out.println("✅ Stok berhasil diupdate untuk: " + detail.getIdMenu() + " x" + detail.getJumlah());
                }
            }
            return true; // Return true meski ada yang gagal, karena pesanan sudah tercatat
        } catch (Exception e) {
            System.out.println("❌ Error update stok: " + e.getMessage());
            return false;
        }
    }

    // ✅ UPDATE METHOD TAMPILKAN STRUK
    private void tampilkanStruk(Pesanan pesanan, List<DetailPesanan> details) {
        StringBuilder struk = new StringBuilder();
        struk.append("=================================\n");
        struk.append("           STRUK PEMBAYARAN       \n");
        struk.append("=================================\n");
        struk.append("ID Pesanan : ").append(pesanan.getIdPesanan()).append("\n");
        
        // ✅ PASTIKAN TANGGAL TIDAK NULL
        String tanggalStr;
        try {
            tanggalStr = pesanan.getTanggalPesanan().toString();
        } catch (Exception e) {
            tanggalStr = java.time.LocalDateTime.now().toString();
        }
        struk.append("Tanggal    : ").append(tanggalStr).append("\n");
        
        struk.append("Kasir      : ").append(namaKasir != null ? namaKasir : "System").append("\n");
        struk.append("No Meja    : ").append(noMeja == 0 ? "Take Away" : "Meja " + noMeja).append("\n");
        struk.append("---------------------------------\n");
        struk.append("Item              Qty    Subtotal\n");
        struk.append("---------------------------------\n");
        
        for (DetailPesanan detail : details) {
            String namaMenu = detail.getMenu().getNamaMenu();
            if (namaMenu.length() > 15) {
                namaMenu = namaMenu.substring(0, 15) + "...";
            }
            struk.append(String.format("%-15s %3d   %9s\n", 
                namaMenu, 
                detail.getJumlah(),
                "Rp " + String.format("%,.0f", detail.getSubtotal())
            ));
        }
        
        struk.append("---------------------------------\n");
        struk.append(String.format("TOTAL: %23s\n", "Rp " + String.format("%,.0f", pesanan.getTotal())));
        struk.append("=================================\n");
        struk.append("     Terima kasih atas kunjungannya!\n");
        
        JOptionPane.showMessageDialog(null, struk.toString(), "Struk Pembayaran", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean updateJumlahKeranjang(String idMenu, int jumlahBaru) {
        for (DetailPesanan detail : keranjang) {
            if (detail.getIdMenu().equals(idMenu)) {
                if (jumlahBaru <= 0) {
                    return hapusDariKeranjang(idMenu);
                }

                // ✅ CEK STOK UNTUK JUMLAH BARU
                int stokTersedia = stokService.getTotalStokTersedia(idMenu);
                if (stokTersedia < jumlahBaru) {
                    JOptionPane.showMessageDialog(null,
                            "Stok tidak cukup!\nStok tersedia: " + stokTersedia,
                            "Stok Habis", JOptionPane.WARNING_MESSAGE);
                    return false;
                }

                detail.setJumlah(jumlahBaru);
                detail.setSubtotal(detail.getMenu().getHarga() * jumlahBaru);
                return true;
            }
        }
        return false;
    }

    public int getJumlahItemKeranjang() {
        return keranjang.size();
    }
}